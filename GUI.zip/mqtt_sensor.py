import paho.mqtt.client as mqtt
import threading
import time

# MQTT config
mqtt_broker_address = "raspberrypi2b"
mqtt_topic = "sensor_data"

# store value
temperature = 0.0
humidity = 0
windspeed = 0.0

def on_connect(client, userdata, flags, rc):
    global temperature, humidity, windspeed
    print("Connected with result code " + str(rc))
    # subscribe
    client.subscribe(mqtt_topic)

def on_message(client, userdata, msg):
    global temperature, humidity, windspeed

    message = msg.payload.decode("utf-8")
    print("Received:", message)

    # get value from mqtt
    parts = message.split(", ")
    for part in parts:
        key, value = part.split(": ")
        if key == "Temperature":
            temperature = float(value)
        elif key == "Humidity":
            humidity = int(value)
        elif key == "Windspeed":
            windspeed = float(value)

# create MQTT client
client = mqtt.Client()

# set call back
client.on_connect = on_connect
client.on_message = on_message

def mqtt_loop():
    # connect mqtt
    client.connect(mqtt_broker_address, 1883, 60)
    # keep getting message
    client.loop_forever()

# print value
print(f"Temperature: {temperature}°C, Humidity: {humidity}%, Windspeed: {windspeed}")

# start mqtt
mqtt_thread = threading.Thread(target=mqtt_loop)
mqtt_thread.start()




