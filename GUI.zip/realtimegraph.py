from PyQt5 import QtWidgets
from PyQt5.QtCore import QTimer
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

class RealTimeGraph(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.figure)
        self.layout = QtWidgets.QVBoxLayout()
        self.layout.addWidget(self.canvas)
        self.setLayout(self.layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_graph)
        self.graph_data = {'Temp': [], 'Humidity': [], 'Wind Speed': []}
        self.current_graph = 'Temp'

    def start_timer(self):
        self.timer.start(1000)  # update every second

    def update_graph(self, temperature=None, humidity=None, windspeed=None):
        if temperature is not None:
            self.graph_data['Temp'].append(temperature)
        if humidity is not None:
            self.graph_data['Humidity'].append(humidity)
        if windspeed is not None:
            self.graph_data['Wind Speed'].append(windspeed)

        self.ax.clear()
        self.ax.plot(self.graph_data[self.current_graph], label=self.current_graph)
        self.ax.legend()
        self.canvas.draw()


if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    real_time_graph = RealTimeGraph()
    real_time_graph.start_timer()
    real_time_graph.show()
    app.exec_()
