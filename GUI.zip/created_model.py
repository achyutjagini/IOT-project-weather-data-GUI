import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
import time
import os
import datetime
import IPython
import IPython.display
import matplotlib as mpl
import tensorflow as tf
from tensorflow import keras
from keras.models import Sequential
from keras.layers import LSTM, Dense, Input
from sklearn.metrics import confusion_matrix
#from google.colab import drive

#drive.mount('/content/gdrive')

df_weather = pd.read_csv('weatherHistory.csv')

df_weather.info()

df_weather[20: 400:24]

print ("Unique values are:\n",df_weather.nunique())

df_weather = df_weather.sort_values(by='Formatted Date')

df_weather[20: 400:24]

wt_missing = df_weather.isna().sum()
wt_missing

missing_value_count = (df_weather.isnull().sum())
print(missing_value_count[missing_value_count > 0])
total_cells = np.product(df_weather.shape)
total_missing_value = missing_value_count.sum()
print("Total percentage of our missing value is:",round((total_missing_value / total_cells * 100),4))
print('Total number of our cells is :',total_cells)
print('Total number of our missing value is :',total_missing_value)

df_weather['Precip Type'].fillna(df_weather['Precip Type'].value_counts().index[0],inplace=True)
df_weather.isna().sum()

df_weather.drop(["Daily Summary"], axis=1, inplace=True)

df_weather.columns

df_weather['Loud Cover'].value_counts()

df_weather.drop(['Loud Cover'],axis=1,inplace=True)

df_weather.columns

Summary_Weather=df_weather["Summary"].value_counts().reset_index()
Summary_Weather.columns=["Weather Type","Count"]
Summary_Weather

print(df_weather['Summary'].unique())

df_weather = pd.get_dummies(df_weather, columns = ['Summary'])
print(df_weather)

precip_Label= df_weather["Precip Type"].value_counts().reset_index()
precip_Label.columns=["Precip Type","Count"]
precip_Label

le = LabelEncoder()
df_weather['Precip Type']=le.fit_transform(df_weather['Precip Type'])
df_weather.head(10)

df_weather.head(20)

date_time = pd.to_datetime(df_weather.pop('Formatted Date'), format='%Y-%m-%d %H:%M:%S.%f %z')
plot_cols = df_weather.columns
plot_features = df_weather[plot_cols]
plot_features.index = date_time
plot_features.plot( figsize=(20,35), subplots=True)

df_weather.describe().transpose()

df_weather["Pressure (millibars)"].value_counts()

pressure = df_weather['Pressure (millibars)']
bad_pressure = pressure == 0
pressure[bad_pressure].count()

print("Total percentage of our error value is:",round((pressure[bad_pressure].count() / pressure.count() * 100),4))

pressure.loc[bad_pressure] = pressure.mean()

#visualization
plot_cols = df_weather.columns
plot_features = df_weather[plot_cols][:480]
plot_features.index = date_time[:480]
_ = plot_features.plot(figsize=(20,30), subplots=True)

plt.hist2d(df_weather['Wind Bearing (degrees)'], df_weather['Wind Speed (km/h)'], bins=(50, 50), vmax=300)
plt.colorbar()
plt.xlabel('Wind Direction [degrees]')
plt.ylabel('Wind Velocity [km/h]')

wv = df_weather.pop('Wind Speed (km/h)')

# Convert to radians.
wd_rad = df_weather.pop('Wind Bearing (degrees)')*np.pi / 180

# Calculate the wind x and y components.
df_weather['Wx'] = wv*np.cos(wd_rad)
df_weather['Wy'] = wv*np.sin(wd_rad)


plt.hist2d(df_weather['Wx'], df_weather['Wy'], bins=(50, 50), vmax=400)
plt.colorbar()
plt.xlabel('Wind X [km/h]')
plt.ylabel('Wind Y [km/h]')
ax = plt.gca()
ax.axis('tight')

timestamp_s = date_time.apply(pd.Timestamp.timestamp)
day = 24*60*60
year = (365.2425)*day

df_weather['Day sin'] = np.sin(timestamp_s * (2 * np.pi / day))
df_weather['Day cos'] = np.cos(timestamp_s * (2 * np.pi / day))
df_weather['Year sin'] = np.sin(timestamp_s * (2 * np.pi / year))
df_weather['Year cos'] = np.cos(timestamp_s * (2 * np.pi / year))

plt.plot(np.array(df_weather['Day sin'])[:50])
plt.plot(np.array(df_weather['Day cos'])[:50])
plt.xlabel('Time [h]')
plt.title('Time of day signal')

n_timestep = 15
n_timepred = 1

df_weather.columns

from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
df_weather = scaler.fit_transform(df_weather)

df_weather

n = len(df_weather)
train_df = df_weather[0:int(n*0.7)]
val_df = df_weather[int(n*0.7):int(n*0.9)]
test_df = df_weather[int(n*0.9):]

n_feature = df_weather.shape[1]

n_feature

def timestep_split(data, n_step):
    x, y = [], []

    length = len(data)
    for i in range(n_step, length):
        x.append(data[i-n_step:i])
        y.append(data[i])

    return np.array(x), np.array(y)

x_train, y_train = timestep_split(data=train_df, n_step=n_timestep)
x_val, y_val = timestep_split(data=val_df, n_step=n_timestep)
x_test, y_test = timestep_split(data=test_df, n_step=n_timestep)

x_train[0], y_train[0]

model = keras.models.Sequential()

model.add(Input(shape=(n_timestep,n_feature), name='Input'))

model.add(LSTM(units=64,
               activation='tanh',
               recurrent_activation='sigmoid',
               use_bias=True,
               kernel_initializer='glorot_uniform',
               recurrent_initializer='orthogonal',
               bias_initializer='zeros',
               dropout=0.0,
               recurrent_dropout=0.0,
               return_sequences=True,
               name='LSTM_many_to_many'))

model.add(LSTM(units=64,
               activation='tanh',
               recurrent_activation='sigmoid',
               use_bias=True,
               kernel_initializer='glorot_uniform',
               recurrent_initializer='orthogonal',
               bias_initializer='zeros',
               dropout=0.0,
               recurrent_dropout=0.0,
               name='LSTM_many_to_one'))

model.add(Dense(units=n_feature,
                activation='sigmoid',
                use_bias=True,
                kernel_initializer='glorot_uniform',
                bias_initializer='zeros',
                name='Output_layer'))

opt = tf.keras.optimizers.Adam(learning_rate=0.001,
                               beta_1=0.9,
                               beta_2=0.999,
                               epsilon=1e-08)

model.compile(optimizer=opt, loss='mse')

model.summary()

tf.keras.utils.plot_model(model,to_file='/content/gdrive/MyDrive/model/model_LSTM.png', show_layer_activations=True, show_shapes=True, show_layer_names=True)

##timestamp = time.strftime("%Y%m%d%H%M%S")
##path = '/content/gdrive/MyDrive/model/LSTM_model_15timesteps_{timestamp}.h5'
path = '/content/gdrive/MyDrive/model/LSTM_model_15timesteps.h5'
checkpoint = keras.callbacks.ModelCheckpoint(filepath=path, monitor='val_loss', save_best_only=True)

model.fit(x_train, y_train, epochs=75, verbose=0, callbacks=[checkpoint], batch_size=256,validation_data=(x_val, y_val), validation_batch_size=256)

plt.figure(figsize=(19, 6))
plt.plot(model.history.history['loss'], label='train_loss')
plt.plot(model.history.history['val_loss'], c='red', label='val_loss')
plt.legend()

#load best model
model = keras.models.load_model('/content/gdrive/MyDrive/model/LSTM_model_15timesteps.h5')

y_predict = model.predict(x_test)

y_predict_inverse = scaler.inverse_transform(y_predict)
y_test_inverse = scaler.inverse_transform(y_test)

y_predict_inverse[0]

y_test_inverse[0]

rain = y_predict_inverse[:,0] < 0.5
snow = y_predict_inverse[:,0] >= 0.5
y_predict_inverse[rain,0] = 0
y_predict_inverse[snow,0] = 1

BA = keras.metrics.BinaryAccuracy(threshold=0.5)
BA.update_state(y_test_inverse[:,0], y_predict_inverse[:,0])
R_Accuracy = float(BA.result())
print('Accuracy when predicting rain or not: {:.2f}%'.format(R_Accuracy*100))

# compute the confusion matrix
cm = confusion_matrix(y_test_inverse[:,0], y_predict_inverse[:,0])

#Plot the confusion matrix.
sns.heatmap(cm,
            annot=True,
            fmt='g',
            linewidths= 0.2,
            annot_kws={"size": 6})
plt.xlabel('Actual',fontsize=13)
plt.ylabel('Predict',fontsize=13)
plt.title('Confusion Matrix',fontsize=17)

plt.show()

from keras.metrics import mean_absolute_error

# mean absolute error
mean = float(mean_absolute_error(y_test_inverse[:,1], y_predict_inverse[:,1]))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot( date_time[int(n*0.9) + n_timestep:], y_predict_inverse[:,1], label='predict')
plt.plot( date_time[int(n*0.9) + n_timestep:], y_test_inverse[:,1], c='red', label='real')
plt.title('Temperature')
plt.legend()

# mean absolute error
mean = float(mean_absolute_error(y_test_inverse[:,2], y_predict_inverse[:,2]))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], y_predict_inverse[:,2], label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], y_test_inverse[:,2], c='red', label='real')
plt.title('Apparent Temperature (C)')
plt.legend()

# mean absolute error
mean = float(mean_absolute_error(y_test_inverse[:,3], y_predict_inverse[:,3]))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], y_predict_inverse[:,3], label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], y_test_inverse[:,3], c='red', label='real')
plt.title('Humidity')
plt.legend()

# mean absolute error
mean = float(mean_absolute_error(y_test_inverse[:,4], y_predict_inverse[:,4]))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], y_predict_inverse[:,4], label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], y_test_inverse[:,4], c='red', label='real')
plt.title('Visibility (km)')
plt.legend()

# mean absolute error
mean = float(mean_absolute_error(y_test_inverse[:,5], y_predict_inverse[:,5]))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], y_predict_inverse[:,5], label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], y_test_inverse[:,5], c='red', label='real')
plt.title('Pressure (millibars)')
plt.legend()



Summary_Weather['Weather Type']

max_indices_pre = np.argmax(y_predict_inverse[:, 6:33], axis=1)
print(max_indices_pre)

max_indices_test = np.argmax(y_test_inverse[:, 6:33], axis=1)
print(max_indices_test)

from sklearn.metrics import accuracy_score
accuracy_score( max_indices_test,max_indices_pre)

# compute the confusion matrix
cm = confusion_matrix(max_indices_test,max_indices_pre)

#Plot the confusion matrix.

sns.heatmap(cm,
            annot=True,
            fmt='g',
            linewidths= 0.2,
            annot_kws={"size": 6})
# plt.figure(figsize= (5, 5))
plt.xlabel('Actual',fontsize=13)
plt.ylabel('Predict',fontsize=13)
plt.title('Confusion Matrix',fontsize=17)

plt.show()

def convertWind(wx, wy):
    # Convert Wx and Wy to 'Wind Speed (km/h)'
    w_speed = np.sqrt(wx**2 + wy**2)

    # Convert Wx and Wy to 'Wind Bearing (degrees)'
    w_bearing = np.arctan2(wy, wx) * 180 / np.pi
    return w_speed, w_bearing

w_speed_test, w_bearing_test = convertWind(y_test_inverse[:,33], y_test_inverse[:,34])
w_speed_pred, w_bearing_pred = convertWind(y_predict_inverse[:,33], y_predict_inverse[:,34])


# mean absolute error
mean = float(mean_absolute_error(w_speed_test, w_speed_pred))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], w_speed_pred, label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], w_speed_test, c='red', label='real')
plt.title('Wind Speed (km/h)')
plt.legend()

# mean absolute error
mean = float(mean_absolute_error(w_bearing_test, w_bearing_pred))
print('The average deviation is: {:.3f}'.format(mean))

#visualization
plt.figure(figsize=(50,10))
plt.plot(date_time[int(n*0.9) + n_timestep:], w_bearing_pred, label='predict')
plt.plot(date_time[int(n*0.9) + n_timestep:], w_bearing_test, c='red', label='real')
plt.title('Wind Bearing (degrees)')
plt.legend()








